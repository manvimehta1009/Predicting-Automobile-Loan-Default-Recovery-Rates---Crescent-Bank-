select count(*)
from input_data_3;
/*Removed 1 row which was not matching the table values */
select count(*)
from input_data_1;

select count(*)
from input_data_2;

select count(distinct(input_data_3.masked_acct))
from input_data_3;   

select count(distinct(input_data_1.masked_acct))
from input_data_1;

select count(distinct(input_data_2.masked_acct))
from input_data_2

/*Total DISTINCT values = 3718 + 5000 + 5000*/
/*All the tables had repeated rows for each row */
/*# I am checking if there are matching keys and masked_acct with the first 3 tables*/
SELECT count(*)
from input_data_1 a1, input_data_2 a2 
where a1.key_1= a2.key_1

SELECT count(*)
from input_data_1 a1, input_data_3 a2 
where a1.masked_acct= a2.masked_acct


SELECT count(*)
from input_data_2 a1, input_data_3 a2 
where a1.masked_acct= a2.masked_acct

/*After verifyig that there ARE NO matching keys in the input_data_1, input_data_2, input_data_3*, I came to a comclusion of USING the union operation*/
/*All the tables had each row repeated exactly 1 times. Basically, instead of using union all, I can use UNION so that issue would be handled*/

CREATE TABLE phase1 AS SELECT * FROM input_data_1 UNION SELECT * FROM input_data_2 UNION SELECT * FROM input_data_3

select count(*)
from phase1;
/* Here phase1 is the the union of first 3 input table with their distinct values.*/

SELECT count()
from input_data_4

SELECT count()
from input_data_5

SELECT count()
from input_data_6




create table phase2 as 
select * 
from phase1 a, input_data_4 b
where a.key_1 = b.key_1 
UNION
SELECT * 
from phase1 a, input_data_5 b
where a.key_1= b.key_1
UNION
SELECT * 
from phase1 a, input_data_6 b
where a.key_1= b.key_1
/*Above query to create the final phase2 table. Basically, first 6 inuput tables has been delt with*/


SELECT count(distinct(phase2.masked_acct))
from phase2
/*I verified that no masked_acct id is repeated*/


/*Created the phase3 table same way like phase2 by joining the input_data_[7-9] to phase2.*/
create table phase3 as 
select * 
from phase2 a, input_data_7 b
where a.key_2 = b.key_2 
UNION
SELECT * 
from phase2 a, input_data_8 b
where a.key_2= b.key_2
UNION
SELECT * 
from phase2 a, input_data_9 b
where a.key_2= b.key_2





SELECT COUNT(DISTINCT(masked_acct))
from phase3


/* Creating a table for Target varible to get the average recovery rate /*/

CREATE TABLE phase4 as
select a.masked_acct,  AVG(a.RecoveryRate) as FinalRecoveryRate 
from (select a.masked_acct,max(score_ind) as score_ind, RecoveryPctBalanceAtDefaultRatioMACO12 as RecoveryRate 
from target a, (SELECT masked_acct,max(score_ind) as score1 from target GROUP BY masked_acct ) as b 
where  a.masked_acct = b.masked_acct and a.score_ind!=b.score1
GROUP BY a.masked_acct
UNION
select masked_acct,min(score_ind) as score_ind, RecoveryPctBalanceAtDefaultRatioMACO12 as RecoveryRate
from target 
GROUP by masked_acct) as a 
group by a.masked_acct


SELECT COUNT(DISTINCT(masked_acct))
from phase4

/*Connect the table phase3 to get the final table*/
create table phase5 as 
select *
from phase3 a, phase4 b
WHERE a.masked_acct = b.masked_acct 
