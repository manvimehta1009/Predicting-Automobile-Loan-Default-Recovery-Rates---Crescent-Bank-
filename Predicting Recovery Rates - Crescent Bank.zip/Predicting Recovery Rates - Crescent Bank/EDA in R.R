Final_Data <- read.csv("D:/CRESENT BANK HACKATHON/Final_Data1.csv", header=TRUE)
View(Final_Data)

typeof(Final_Data$StateApplicant)

Final_Data$StateApplicant <- as.factor(Final_Data$StateApplicant)

one.way <- aov(Final_Data$FinalRecoveryRate ~ Final_Data$StateApplicant, data = Final_Data)

summary(one.way)


Final_Data$VehicleMakeNADA <- as.factor(Final_Data$VehicleMakeNADA)
Final_Data$VehicleMakeNADA[is.na(Final_Data$VehicleMakeNADA)] <- 'NONE'

one.way <- aov(Final_Data$FinalRecoveryRate ~ Final_Data$VehicleMakeNADA, data = Final_Data)

summary(one.way)



